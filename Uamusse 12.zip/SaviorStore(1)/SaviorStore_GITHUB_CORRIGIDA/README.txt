SAVIOR STORE - PUBLICAÇÃO NO GITHUB PAGES

IMPORTANTE: Este ZIP foi organizado para que index.html fique directamente na raiz do repositório.

ESTRUTURA:
index.html          Apresentação pública (página inicial)
entrar.html         Login e criação de conta
loja.html           Página alternativa de apresentação
css/style.css       Estilos da plataforma
js/data.js          Dados e produtos
js/auth.js          Login e registo
js/admin.js         Funcionalidades administrativas
js/reseller.js      Funcionalidades do revendedor
admin/              Painel do administrador
revendedor/         Páginas do revendedor

COMO PUBLICAR:
1. Extrai este ZIP.
2. Abre o repositório Savior-Store no GitHub.
3. Entra em Add file > Upload files.
4. Selecciona TODOS os ficheiros e pastas que estão DENTRO da pasta extraída.
5. Não envies a pasta exterior como uma única pasta e não envies o ZIP.
6. Confirma em Commit changes.
7. Em Settings > Pages, selecciona Deploy from a branch, branch main e folder /(root).
8. Abre https://uamussesalvador.github.io/Savior-Store/

Atenção: index.html deve aparecer directamente na página principal do repositório, ao mesmo nível de css, js, admin e revendedor.

CONTAS DE DEMONSTRAÇÃO:
Administrador: admin
Palavra-passe: admin123
Revendedor: revendedor
Palavra-passe: revendedor123

O protótipo usa LocalStorage. As contas e pedidos ficam guardados apenas no navegador/dispositivo utilizado; não existe ainda uma base de dados online partilhada. Use dados fictícios na demonstração.
